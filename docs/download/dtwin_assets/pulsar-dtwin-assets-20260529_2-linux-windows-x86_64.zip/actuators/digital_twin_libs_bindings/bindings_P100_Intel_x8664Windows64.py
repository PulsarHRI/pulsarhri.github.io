r"""Wrapper for interface.h

Generated with:
ctypesgen --allow-gnu-c --no-macros --no-undefs -IDT_ert_rtw -l libP100_Intel_x8664Windows64.dll interface.h DT.h -o bindings_P100_Intel_x8664Windows64.py

Do not modify this file.
"""

__docformat__ = "restructuredtext"

# Begin preamble for Python

import ctypes
import sys
from ctypes import *  # noqa: F401, F403

_int_types = (ctypes.c_int16, ctypes.c_int32)
if hasattr(ctypes, "c_int64"):
    # Some builds of ctypes apparently do not have ctypes.c_int64
    # defined; it's a pretty good bet that these builds do not
    # have 64-bit pointers.
    _int_types += (ctypes.c_int64,)
for t in _int_types:
    if ctypes.sizeof(t) == ctypes.sizeof(ctypes.c_size_t):
        c_ptrdiff_t = t
del t
del _int_types



class UserString:
    def __init__(self, seq):
        if isinstance(seq, bytes):
            self.data = seq
        elif isinstance(seq, UserString):
            self.data = seq.data[:]
        else:
            self.data = str(seq).encode()

    def __bytes__(self):
        return self.data

    def __str__(self):
        return self.data.decode()

    def __repr__(self):
        return repr(self.data)

    def __int__(self):
        return int(self.data.decode())

    def __long__(self):
        return int(self.data.decode())

    def __float__(self):
        return float(self.data.decode())

    def __complex__(self):
        return complex(self.data.decode())

    def __hash__(self):
        return hash(self.data)

    def __le__(self, string):
        if isinstance(string, UserString):
            return self.data <= string.data
        else:
            return self.data <= string

    def __lt__(self, string):
        if isinstance(string, UserString):
            return self.data < string.data
        else:
            return self.data < string

    def __ge__(self, string):
        if isinstance(string, UserString):
            return self.data >= string.data
        else:
            return self.data >= string

    def __gt__(self, string):
        if isinstance(string, UserString):
            return self.data > string.data
        else:
            return self.data > string

    def __eq__(self, string):
        if isinstance(string, UserString):
            return self.data == string.data
        else:
            return self.data == string

    def __ne__(self, string):
        if isinstance(string, UserString):
            return self.data != string.data
        else:
            return self.data != string

    def __contains__(self, char):
        return char in self.data

    def __len__(self):
        return len(self.data)

    def __getitem__(self, index):
        return self.__class__(self.data[index])

    def __getslice__(self, start, end):
        start = max(start, 0)
        end = max(end, 0)
        return self.__class__(self.data[start:end])

    def __add__(self, other):
        if isinstance(other, UserString):
            return self.__class__(self.data + other.data)
        elif isinstance(other, bytes):
            return self.__class__(self.data + other)
        else:
            return self.__class__(self.data + str(other).encode())

    def __radd__(self, other):
        if isinstance(other, bytes):
            return self.__class__(other + self.data)
        else:
            return self.__class__(str(other).encode() + self.data)

    def __mul__(self, n):
        return self.__class__(self.data * n)

    __rmul__ = __mul__

    def __mod__(self, args):
        return self.__class__(self.data % args)

    # the following methods are defined in alphabetical order:
    def capitalize(self):
        return self.__class__(self.data.capitalize())

    def center(self, width, *args):
        return self.__class__(self.data.center(width, *args))

    def count(self, sub, start=0, end=sys.maxsize):
        return self.data.count(sub, start, end)

    def decode(self, encoding=None, errors=None):  # XXX improve this?
        if encoding:
            if errors:
                return self.__class__(self.data.decode(encoding, errors))
            else:
                return self.__class__(self.data.decode(encoding))
        else:
            return self.__class__(self.data.decode())

    def encode(self, encoding=None, errors=None):  # XXX improve this?
        if encoding:
            if errors:
                return self.__class__(self.data.encode(encoding, errors))
            else:
                return self.__class__(self.data.encode(encoding))
        else:
            return self.__class__(self.data.encode())

    def endswith(self, suffix, start=0, end=sys.maxsize):
        return self.data.endswith(suffix, start, end)

    def expandtabs(self, tabsize=8):
        return self.__class__(self.data.expandtabs(tabsize))

    def find(self, sub, start=0, end=sys.maxsize):
        return self.data.find(sub, start, end)

    def index(self, sub, start=0, end=sys.maxsize):
        return self.data.index(sub, start, end)

    def isalpha(self):
        return self.data.isalpha()

    def isalnum(self):
        return self.data.isalnum()

    def isdecimal(self):
        return self.data.isdecimal()

    def isdigit(self):
        return self.data.isdigit()

    def islower(self):
        return self.data.islower()

    def isnumeric(self):
        return self.data.isnumeric()

    def isspace(self):
        return self.data.isspace()

    def istitle(self):
        return self.data.istitle()

    def isupper(self):
        return self.data.isupper()

    def join(self, seq):
        return self.data.join(seq)

    def ljust(self, width, *args):
        return self.__class__(self.data.ljust(width, *args))

    def lower(self):
        return self.__class__(self.data.lower())

    def lstrip(self, chars=None):
        return self.__class__(self.data.lstrip(chars))

    def partition(self, sep):
        return self.data.partition(sep)

    def replace(self, old, new, maxsplit=-1):
        return self.__class__(self.data.replace(old, new, maxsplit))

    def rfind(self, sub, start=0, end=sys.maxsize):
        return self.data.rfind(sub, start, end)

    def rindex(self, sub, start=0, end=sys.maxsize):
        return self.data.rindex(sub, start, end)

    def rjust(self, width, *args):
        return self.__class__(self.data.rjust(width, *args))

    def rpartition(self, sep):
        return self.data.rpartition(sep)

    def rstrip(self, chars=None):
        return self.__class__(self.data.rstrip(chars))

    def split(self, sep=None, maxsplit=-1):
        return self.data.split(sep, maxsplit)

    def rsplit(self, sep=None, maxsplit=-1):
        return self.data.rsplit(sep, maxsplit)

    def splitlines(self, keepends=0):
        return self.data.splitlines(keepends)

    def startswith(self, prefix, start=0, end=sys.maxsize):
        return self.data.startswith(prefix, start, end)

    def strip(self, chars=None):
        return self.__class__(self.data.strip(chars))

    def swapcase(self):
        return self.__class__(self.data.swapcase())

    def title(self):
        return self.__class__(self.data.title())

    def translate(self, *args):
        return self.__class__(self.data.translate(*args))

    def upper(self):
        return self.__class__(self.data.upper())

    def zfill(self, width):
        return self.__class__(self.data.zfill(width))


class MutableString(UserString):
    """mutable string objects

    Python strings are immutable objects.  This has the advantage, that
    strings may be used as dictionary keys.  If this property isn't needed
    and you insist on changing string values in place instead, you may cheat
    and use MutableString.

    But the purpose of this class is an educational one: to prevent
    people from inventing their own mutable string class derived
    from UserString and than forget thereby to remove (override) the
    __hash__ method inherited from UserString.  This would lead to
    errors that would be very hard to track down.

    A faster and better solution is to rewrite your program using lists."""

    def __init__(self, string=""):
        self.data = string

    def __hash__(self):
        raise TypeError("unhashable type (it is mutable)")

    def __setitem__(self, index, sub):
        if index < 0:
            index += len(self.data)
        if index < 0 or index >= len(self.data):
            raise IndexError
        self.data = self.data[:index] + sub + self.data[index + 1 :]

    def __delitem__(self, index):
        if index < 0:
            index += len(self.data)
        if index < 0 or index >= len(self.data):
            raise IndexError
        self.data = self.data[:index] + self.data[index + 1 :]

    def __setslice__(self, start, end, sub):
        start = max(start, 0)
        end = max(end, 0)
        if isinstance(sub, UserString):
            self.data = self.data[:start] + sub.data + self.data[end:]
        elif isinstance(sub, bytes):
            self.data = self.data[:start] + sub + self.data[end:]
        else:
            self.data = self.data[:start] + str(sub).encode() + self.data[end:]

    def __delslice__(self, start, end):
        start = max(start, 0)
        end = max(end, 0)
        self.data = self.data[:start] + self.data[end:]

    def immutable(self):
        return UserString(self.data)

    def __iadd__(self, other):
        if isinstance(other, UserString):
            self.data += other.data
        elif isinstance(other, bytes):
            self.data += other
        else:
            self.data += str(other).encode()
        return self

    def __imul__(self, n):
        self.data *= n
        return self


class String(MutableString, ctypes.Union):

    _fields_ = [("raw", ctypes.POINTER(ctypes.c_char)), ("data", ctypes.c_char_p)]

    def __init__(self, obj=b""):
        if isinstance(obj, (bytes, UserString)):
            self.data = bytes(obj)
        else:
            self.raw = obj

    def __len__(self):
        return self.data and len(self.data) or 0

    def from_param(cls, obj):
        # Convert None or 0
        if obj is None or obj == 0:
            return cls(ctypes.POINTER(ctypes.c_char)())

        # Convert from String
        elif isinstance(obj, String):
            return obj

        # Convert from bytes
        elif isinstance(obj, bytes):
            return cls(obj)

        # Convert from str
        elif isinstance(obj, str):
            return cls(obj.encode())

        # Convert from c_char_p
        elif isinstance(obj, ctypes.c_char_p):
            return obj

        # Convert from POINTER(ctypes.c_char)
        elif isinstance(obj, ctypes.POINTER(ctypes.c_char)):
            return obj

        # Convert from raw pointer
        elif isinstance(obj, int):
            return cls(ctypes.cast(obj, ctypes.POINTER(ctypes.c_char)))

        # Convert from ctypes.c_char array
        elif isinstance(obj, ctypes.c_char * len(obj)):
            return obj

        # Convert from object
        else:
            return String.from_param(obj._as_parameter_)

    from_param = classmethod(from_param)


def ReturnString(obj, func=None, arguments=None):
    return String.from_param(obj)


# As of ctypes 1.0, ctypes does not support custom error-checking
# functions on callbacks, nor does it support custom datatypes on
# callbacks, so we must ensure that all callbacks return
# primitive datatypes.
#
# Non-primitive return values wrapped with UNCHECKED won't be
# typechecked, and will be converted to ctypes.c_void_p.
def UNCHECKED(type):
    if hasattr(type, "_type_") and isinstance(type._type_, str) and type._type_ != "P":
        return type
    else:
        return ctypes.c_void_p


# ctypes doesn't have direct support for variadic functions, so we have to write
# our own wrapper class
class _variadic_function(object):
    def __init__(self, func, restype, argtypes, errcheck):
        self.func = func
        self.func.restype = restype
        self.argtypes = argtypes
        if errcheck:
            self.func.errcheck = errcheck

    def _as_parameter_(self):
        # So we can pass this variadic function as a function pointer
        return self.func

    def __call__(self, *args):
        fixed_args = []
        i = 0
        for argtype in self.argtypes:
            # Typecheck what we can
            fixed_args.append(argtype.from_param(args[i]))
            i += 1
        return self.func(*fixed_args + list(args[i:]))


def ord_if_char(value):
    """
    Simple helper used for casts to simple builtin types:  if the argument is a
    string type, it will be converted to it's ordinal value.

    This function will raise an exception if the argument is string with more
    than one characters.
    """
    return ord(value) if (isinstance(value, bytes) or isinstance(value, str)) else value

# End preamble

_libs = {}
_libdirs = []

# Begin loader

"""
Load libraries - appropriately for all our supported platforms
"""
# ----------------------------------------------------------------------------
# Copyright (c) 2008 David James
# Copyright (c) 2006-2008 Alex Holkner
# All rights reserved.
#
# Redistribution and use in source and binary forms, with or without
# modification, are permitted provided that the following conditions
# are met:
#
#  * Redistributions of source code must retain the above copyright
#    notice, this list of conditions and the following disclaimer.
#  * Redistributions in binary form must reproduce the above copyright
#    notice, this list of conditions and the following disclaimer in
#    the documentation and/or other materials provided with the
#    distribution.
#  * Neither the name of pyglet nor the names of its
#    contributors may be used to endorse or promote products
#    derived from this software without specific prior written
#    permission.
#
# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
# "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
# LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
# FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
# COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
# INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
# BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
# LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
# CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
# LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
# ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
# POSSIBILITY OF SUCH DAMAGE.
# ----------------------------------------------------------------------------

import ctypes
import ctypes.util
import glob
import os.path
import platform
import re
import sys


def _environ_path(name):
    """Split an environment variable into a path-like list elements"""
    if name in os.environ:
        return os.environ[name].split(":")
    return []


class LibraryLoader:
    """
    A base class For loading of libraries ;-)
    Subclasses load libraries for specific platforms.
    """

    # library names formatted specifically for platforms
    name_formats = ["%s"]

    class Lookup:
        """Looking up calling conventions for a platform"""

        mode = ctypes.DEFAULT_MODE

        def __init__(self, path):
            super(LibraryLoader.Lookup, self).__init__()
            self.access = dict(cdecl=ctypes.CDLL(path, self.mode))

        def get(self, name, calling_convention="cdecl"):
            """Return the given name according to the selected calling convention"""
            if calling_convention not in self.access:
                raise LookupError(
                    "Unknown calling convention '{}' for function '{}'".format(
                        calling_convention, name
                    )
                )
            return getattr(self.access[calling_convention], name)

        def has(self, name, calling_convention="cdecl"):
            """Return True if this given calling convention finds the given 'name'"""
            if calling_convention not in self.access:
                return False
            return hasattr(self.access[calling_convention], name)

        def __getattr__(self, name):
            return getattr(self.access["cdecl"], name)

    def __init__(self):
        self.other_dirs = []

    def __call__(self, libname):
        """Given the name of a library, load it."""
        paths = self.getpaths(libname)

        for path in paths:
            # noinspection PyBroadException
            try:
                return self.Lookup(path)
            except Exception:  # pylint: disable=broad-except
                pass

        raise ImportError("Could not load %s." % libname)

    def getpaths(self, libname):
        """Return a list of paths where the library might be found."""
        if os.path.isabs(libname):
            yield libname
        else:
            # search through a prioritized series of locations for the library

            # we first search any specific directories identified by user
            for dir_i in self.other_dirs:
                for fmt in self.name_formats:
                    # dir_i should be absolute already
                    yield os.path.join(dir_i, fmt % libname)

            # check if this code is even stored in a physical file
            try:
                this_file = __file__
            except NameError:
                this_file = None

            # then we search the directory where the generated python interface is stored
            if this_file is not None:
                for fmt in self.name_formats:
                    yield os.path.abspath(os.path.join(os.path.dirname(__file__), fmt % libname))

            # now, use the ctypes tools to try to find the library
            for fmt in self.name_formats:
                path = ctypes.util.find_library(fmt % libname)
                if path:
                    yield path

            # then we search all paths identified as platform-specific lib paths
            for path in self.getplatformpaths(libname):
                yield path

            # Finally, we'll try the users current working directory
            for fmt in self.name_formats:
                yield os.path.abspath(os.path.join(os.path.curdir, fmt % libname))

    def getplatformpaths(self, _libname):  # pylint: disable=no-self-use
        """Return all the library paths available in this platform"""
        return []


# Darwin (Mac OS X)


class DarwinLibraryLoader(LibraryLoader):
    """Library loader for MacOS"""

    name_formats = [
        "lib%s.dylib",
        "lib%s.so",
        "lib%s.bundle",
        "%s.dylib",
        "%s.so",
        "%s.bundle",
        "%s",
    ]

    class Lookup(LibraryLoader.Lookup):
        """
        Looking up library files for this platform (Darwin aka MacOS)
        """

        # Darwin requires dlopen to be called with mode RTLD_GLOBAL instead
        # of the default RTLD_LOCAL.  Without this, you end up with
        # libraries not being loadable, resulting in "Symbol not found"
        # errors
        mode = ctypes.RTLD_GLOBAL

    def getplatformpaths(self, libname):
        if os.path.pathsep in libname:
            names = [libname]
        else:
            names = [fmt % libname for fmt in self.name_formats]

        for directory in self.getdirs(libname):
            for name in names:
                yield os.path.join(directory, name)

    @staticmethod
    def getdirs(libname):
        """Implements the dylib search as specified in Apple documentation:

        http:Conceptual/
            DynamicLibrariesDynamicLibraryUsageGuidelines.html

        Before commencing the standard search, the method first checks
        the bundle's ``Frameworks`` directory if the application is running
        within a bundle (OS X .app).
        """

        dyld_fallback_library_path = _environ_path("DYLD_FALLBACK_LIBRARY_PATH")
        if not dyld_fallback_library_path:
            dyld_fallback_library_path = [
                os.path.expanduser("~/lib"),
                "lib",
                "lib",
            ]

        dirs = []

        if "/" in libname:
            dirs.extend(_environ_path("DYLD_LIBRARY_PATH"))
        else:
            dirs.extend(_environ_path("LD_LIBRARY_PATH"))
            dirs.extend(_environ_path("DYLD_LIBRARY_PATH"))
            dirs.extend(_environ_path("LD_RUN_PATH"))

        if hasattr(sys, "frozen") and getattr(sys, "frozen") == "macosx_app":
            dirs.append(os.path.join(os.environ["RESOURCEPATH"], "..", "Frameworks"))

        dirs.extend(dyld_fallback_library_path)

        return dirs


# Posix


class PosixLibraryLoader(LibraryLoader):
    """Library loader for POSIX-like systems (including Linux)"""

    _ld_so_cache = None

    _include = re.compile(r"^\s*include\s+(?P<pattern>.*)")

    name_formats = ["lib%s.so", "%s.so", "%s"]

    class _Directories(dict):
        """Deal with directories"""

        def __init__(self):
            dict.__init__(self)
            self.order = 0

        def add(self, directory):
            """Add a directory to our current set of directories"""
            if len(directory) > 1:
                directory = directory.rstrip(os.path.sep)
            # only adds and updates order if exists and not already in set
            if not os.path.exists(directory):
                return
            order = self.setdefault(directory, self.order)
            if order == self.order:
                self.order += 1

        def extend(self, directories):
            """Add a list of directories to our set"""
            for a_dir in directories:
                self.add(a_dir)

        def ordered(self):
            """Sort the list of directories"""
            return (i[0] for i in sorted(self.items(), key=lambda d: d[1]))

    def _get_ld_so_conf_dirs(self, conf, dirs):
        """
        Recursive function to help parse all ld.so.conf files, including proper
        handling of the `include` directive.
        """

        try:
            with open(conf) as fileobj:
                for dirname in fileobj:
                    dirname = dirname.strip()
                    if not dirname:
                        continue

                    match = self._include.match(dirname)
                    if not match:
                        dirs.add(dirname)
                    else:
                        for dir2 in glob.glob(match.group("pattern")):
                            self._get_ld_so_conf_dirs(dir2, dirs)
        except IOError:
            pass

    def _create_ld_so_cache(self):
        # Recreate search path followed by ld.so.  This is going to be
        # slow to build, and incorrect (ld.so uses ld.so.cache, which may
        # not be up-to-date).  Used only as fallback for distros without
        # ldconfig.
        #
        # We assume the DT_RPATH and DT_RUNPATH binary sections are omitted.

        directories = self._Directories()
        for name in (
            "LD_LIBRARY_PATH",
            "SHLIB_PATH",  # HP-UX
            "LIBPATH",  # OS/2, AIX
            "LIBRARY_PATH",  # BE/OS
        ):
            if name in os.environ:
                directories.extend(os.environ[name].split(os.pathsep))

        self._get_ld_so_conf_dirs("ld.so.conf", directories)

        bitage = platform.architecture()[0]

        unix_lib_dirs_list = []
        if bitage.startswith("64"):
            # prefer 64 bit if that is our arch
            unix_lib_dirs_list += ["/lib64", "lib64"]

        # must include standard libs, since those paths are also used by 64 bit
        # installs
        unix_lib_dirs_list += ["/lib", "lib"]
        if sys.platform.startswith("linux"):
            # Try and support multiarch work in Ubuntu
            # https:MultiarchSpec
            if bitage.startswith("32"):
                # Assume Intel/AMD x86 compat
                unix_lib_dirs_list += ["i386-linux-gnu", "i386-linux-gnu"]
            elif bitage.startswith("64"):
                # Assume Intel/AMD x86 compatible
                unix_lib_dirs_list += [
                    "x86_64-linux-gnu",
                    "x86_64-linux-gnu",
                ]
            else:
                # guess...
                unix_lib_dirs_list += glob.glob("*linux-gnu")
        directories.extend(unix_lib_dirs_list)

        cache = {}
        lib_re = re.compile(r"lib(.*)\.s[ol]")
        # ext_re = re.compile(r"\.s[ol]$")
        for our_dir in directories.ordered():
            try:
                for path in glob.glob("%s/*.s[ol]*" % our_dir):
                    file = os.path.basename(path)

                    # Index by filename
                    cache_i = cache.setdefault(file, set())
                    cache_i.add(path)

                    # Index by library name
                    match = lib_re.match(file)
                    if match:
                        library = match.group(1)
                        cache_i = cache.setdefault(library, set())
                        cache_i.add(path)
            except OSError:
                pass

        self._ld_so_cache = cache

    def getplatformpaths(self, libname):
        if self._ld_so_cache is None:
            self._create_ld_so_cache()

        result = self._ld_so_cache.get(libname, set())
        for i in result:
            # we iterate through all found paths for library, since we may have
            # actually found multiple architectures or other library types that
            # may not load
            yield i


# Windows


class WindowsLibraryLoader(LibraryLoader):
    """Library loader for Microsoft Windows"""

    name_formats = ["%s.dll", "lib%s.dll", "%slib.dll", "%s"]

    class Lookup(LibraryLoader.Lookup):
        """Lookup class for Windows libraries..."""

        def __init__(self, path):
            super(WindowsLibraryLoader.Lookup, self).__init__(path)
            self.access["stdcall"] = ctypes.windll.LoadLibrary(path)


# Platform switching

# If your value of sys.platform does not appear in this dict, please contact
# the Ctypesgen maintainers.

loaderclass = {
    "darwin": DarwinLibraryLoader,
    "cygwin": WindowsLibraryLoader,
    "win32": WindowsLibraryLoader,
    "msys": WindowsLibraryLoader,
}

load_library = loaderclass.get(sys.platform, PosixLibraryLoader)()


def add_library_search_dirs(other_dirs):
    """
    Add libraries to search paths.
    If library paths are relative, convert them to absolute with respect to this
    file's directory
    """
    for path in other_dirs:
        if not os.path.isabs(path):
            path = os.path.abspath(path)
        load_library.other_dirs.append(path)


del loaderclass

# End loader

add_library_search_dirs([])

# Begin libraries
_libs["libP100_Intel_x8664Windows64.dll"] = load_library("libP100_Intel_x8664Windows64.dll")

# 1 libraries
# End libraries

# No modules

int8_T = c_char# rtwtypes.h: 13

uint8_T = c_ubyte# rtwtypes.h: 14

int32_T = c_int# rtwtypes.h: 17

uint32_T = c_uint# rtwtypes.h: 18

real32_T = c_float# rtwtypes.h: 19

real_T = c_double# rtwtypes.h: 21

boolean_T = c_ubyte# rtwtypes.h: 23

char_T = c_char# rtwtypes.h: 27

# DT.h: 346
class struct_tag_RTM_DT_T(Structure):
    pass

RT_MODEL_DT_T = struct_tag_RTM_DT_T# DT_types.h: 4

ZCSigState = uint8_T# zero_crossing_types.h: 11

# DT.h: 23
for _lib in _libs.values():
    try:
        SUBMODULE_COMMITS = (POINTER(c_char)).in_dll(_lib, "SUBMODULE_COMMITS")
        break
    except:
        pass

# DT.h: 24
for _lib in _libs.values():
    try:
        MOTOR_MODEL = (POINTER(c_char)).in_dll(_lib, "MOTOR_MODEL")
        break
    except:
        pass

# DT.h: 25
for _lib in _libs.values():
    try:
        BUILD_TARGET = (POINTER(c_char)).in_dll(_lib, "BUILD_TARGET")
        break
    except:
        pass

# DT.h: 29
class struct_anon_14(Structure):
    pass

struct_anon_14.__slots__ = [
    'UnitDelay_DSTATE',
    'DOB_MODE',
]
struct_anon_14._fields_ = [
    ('UnitDelay_DSTATE', real32_T),
    ('DOB_MODE', boolean_T),
]

DW_DOB_DT_T = struct_anon_14# DT.h: 29

# DT.h: 35
class struct_anon_15(Structure):
    pass

struct_anon_15.__slots__ = [
    'Delay_DSTATE',
    'icLoad',
    'slew_rate_MODE',
]
struct_anon_15._fields_ = [
    ('Delay_DSTATE', real32_T),
    ('icLoad', boolean_T),
    ('slew_rate_MODE', boolean_T),
]

DW_slew_rate_DT_T = struct_anon_15# DT.h: 35

# DT.h: 39
class struct_anon_16(Structure):
    pass

struct_anon_16.__slots__ = [
    'Resetoffsets_Trig_ZCE',
]
struct_anon_16._fields_ = [
    ('Resetoffsets_Trig_ZCE', ZCSigState),
]

ZCE_Resetoffsets_DT_T = struct_anon_16# DT.h: 39

# DT.h: 66
class struct_anon_17(Structure):
    pass

struct_anon_17.__slots__ = [
    'temp_winding',
    'enable',
    'Merge',
    'spd_fb',
    'pos_ref',
    'pos_fb',
    'spd_ref',
    'T_ref',
    'T_fb',
    'id_ref',
    'iq_ref',
    'id_fb',
    'iq_fb',
    'vd_ref',
    'vq_ref',
    'DifferenceInputs2',
    'DifferenceInputs2_o',
    'Saturation',
    'DifferenceInputs2_i',
    'DifferenceInputs2_om',
    'Saturation_g',
    'DifferenceInputs2_e',
    'Saturation_e',
    'Switch1',
]
struct_anon_17._fields_ = [
    ('temp_winding', real_T),
    ('enable', real_T),
    ('Merge', real32_T * int(3)),
    ('spd_fb', real32_T),
    ('pos_ref', real32_T),
    ('pos_fb', real32_T),
    ('spd_ref', real32_T),
    ('T_ref', real32_T),
    ('T_fb', real32_T),
    ('id_ref', real32_T),
    ('iq_ref', real32_T),
    ('id_fb', real32_T),
    ('iq_fb', real32_T),
    ('vd_ref', real32_T),
    ('vq_ref', real32_T),
    ('DifferenceInputs2', real32_T),
    ('DifferenceInputs2_o', real32_T),
    ('Saturation', real32_T),
    ('DifferenceInputs2_i', real32_T),
    ('DifferenceInputs2_om', real32_T),
    ('Saturation_g', real32_T),
    ('DifferenceInputs2_e', real32_T),
    ('Saturation_e', real32_T),
    ('Switch1', uint8_T * int(2)),
]

B_DT_T = struct_anon_17# DT.h: 66

# DT.h: 156
class struct_anon_18(Structure):
    pass

struct_anon_18.__slots__ = [
    'UnitDelay_DSTATE',
    'DiscreteTimeIntegrator_DSTATE',
    'DiscreteTimeIntegrator_DSTATE_j',
    'UnitDelay_DSTATE_h',
    'UnitDelay_DSTATE_o',
    'UnitDelay_DSTATE_n',
    'DiscreteTimeIntegrator_DSTATE_e',
    'NextOutput',
    'NextOutput_e',
    'NextOutput_i',
    'NextOutput_m',
    'NextOutput_e3',
    'Delay_DSTATE',
    'Delay_DSTATE_p',
    'UnitDelay_DSTATE_e',
    'UnitDelay_DSTATE_f',
    'Delay_DSTATE_j',
    'Integrator_DSTATE',
    'Integrator_DSTATE_j',
    'UnitDelay_DSTATE_i',
    'Integrator_DSTATE_js',
    'UnitDelay_DSTATE_c',
    'Integrator_DSTATE_i',
    'Integrator_DSTATE_p',
    'UnitDelay_DSTATE_ee',
    'Integrator_DSTATE_ip',
    'UnitDelay_DSTATE_d',
    'Integrator_DSTATE_g',
    'Integrator_DSTATE_a',
    'UnitDelay_DSTATE_f5',
    'UnitDelay_DSTATE_ew',
    'UnitDelay_DSTATE_do',
    'Integrator_DSTATE_h',
    'Integrator_DSTATE_o',
    'UnitDelay3_DSTATE',
    'Delay_DSTATE_h',
    'UnitDelay1_DSTATE',
    'UnitDelay3_DSTATE_l',
    'Delay_DSTATE_o',
    'UnitDelay1_DSTATE_f',
    'UnitDelay_DSTATE_k',
    'UnitDelay1_DSTATE_k',
    'UnitDelay1_DSTATE_k5',
    'RandSeed',
    'RandSeed_b',
    'RandSeed_f',
    'CircBufIdx',
    'RandSeed_e',
    'CircBufIdx_f',
    'CircBufIdx_n',
    'RandSeed_ea',
    'CircBufIdx_fk',
    'UnitDelay1_DSTATE_j',
    'DelayInput1_DSTATE',
    'UnitDelay_DSTATE_cs',
    'Integrator_PrevResetState',
    'Integrator_PrevResetState_k',
    'Integrator_PrevResetState_f',
    'Integrator_PrevResetState_e',
    'Integrator_PrevResetState_fl',
    'Integrator_PrevResetState_b',
    'Integrator_PrevResetState_o',
    'Integrator_PrevResetState_m',
    'Integrator_PrevResetState_ez',
    'Integrator_PrevResetState_g',
    'icLoad',
    'icLoad_i',
    'icLoad_e',
    'icLoad_iz',
    'icLoad_m',
    'SetMode_MODE',
    'CalibrationAverage_MODE',
    'CalibrationAverage_MODE_c',
    'VoltageInjection_MODE',
    'slew_rate_MODE',
    'PI_Te_MODE',
    'PI_spd_PI_Te_Fric_Comp_MODE',
    'P_pos_PI_spd_PI_Te_Fric_Comp_MO',
    'Openloop_MODE',
    'Impedance_Controller_2_Fric_Com',
    'slew_rate_ok',
    'DOB_e',
    'slew_rate_o',
    'slew_rate_g',
    'DOB_b',
    'slew_rate',
    'DOB',
]
struct_anon_18._fields_ = [
    ('UnitDelay_DSTATE', real_T * int(2)),
    ('DiscreteTimeIntegrator_DSTATE', real_T),
    ('DiscreteTimeIntegrator_DSTATE_j', real_T),
    ('UnitDelay_DSTATE_h', real_T),
    ('UnitDelay_DSTATE_o', real_T),
    ('UnitDelay_DSTATE_n', real_T),
    ('DiscreteTimeIntegrator_DSTATE_e', real_T),
    ('NextOutput', real_T),
    ('NextOutput_e', real_T),
    ('NextOutput_i', real_T),
    ('NextOutput_m', real_T),
    ('NextOutput_e3', real_T),
    ('Delay_DSTATE', real32_T * int(2)),
    ('Delay_DSTATE_p', real32_T * int(2)),
    ('UnitDelay_DSTATE_e', real32_T),
    ('UnitDelay_DSTATE_f', real32_T * int(3)),
    ('Delay_DSTATE_j', real32_T),
    ('Integrator_DSTATE', real32_T),
    ('Integrator_DSTATE_j', real32_T),
    ('UnitDelay_DSTATE_i', real32_T),
    ('Integrator_DSTATE_js', real32_T),
    ('UnitDelay_DSTATE_c', real32_T),
    ('Integrator_DSTATE_i', real32_T),
    ('Integrator_DSTATE_p', real32_T),
    ('UnitDelay_DSTATE_ee', real32_T),
    ('Integrator_DSTATE_ip', real32_T),
    ('UnitDelay_DSTATE_d', real32_T),
    ('Integrator_DSTATE_g', real32_T),
    ('Integrator_DSTATE_a', real32_T),
    ('UnitDelay_DSTATE_f5', real32_T),
    ('UnitDelay_DSTATE_ew', real32_T),
    ('UnitDelay_DSTATE_do', real32_T),
    ('Integrator_DSTATE_h', real32_T),
    ('Integrator_DSTATE_o', real32_T),
    ('UnitDelay3_DSTATE', int32_T * int(2)),
    ('Delay_DSTATE_h', int32_T * int(10)),
    ('UnitDelay1_DSTATE', int32_T),
    ('UnitDelay3_DSTATE_l', int32_T * int(2)),
    ('Delay_DSTATE_o', int32_T * int(10)),
    ('UnitDelay1_DSTATE_f', int32_T),
    ('UnitDelay_DSTATE_k', uint32_T),
    ('UnitDelay1_DSTATE_k', uint32_T),
    ('UnitDelay1_DSTATE_k5', uint32_T),
    ('RandSeed', uint32_T),
    ('RandSeed_b', uint32_T),
    ('RandSeed_f', uint32_T),
    ('CircBufIdx', uint32_T),
    ('RandSeed_e', uint32_T),
    ('CircBufIdx_f', uint32_T),
    ('CircBufIdx_n', uint32_T),
    ('RandSeed_ea', uint32_T),
    ('CircBufIdx_fk', uint32_T),
    ('UnitDelay1_DSTATE_j', uint8_T * int(2)),
    ('DelayInput1_DSTATE', boolean_T),
    ('UnitDelay_DSTATE_cs', boolean_T),
    ('Integrator_PrevResetState', int8_T),
    ('Integrator_PrevResetState_k', int8_T),
    ('Integrator_PrevResetState_f', int8_T),
    ('Integrator_PrevResetState_e', int8_T),
    ('Integrator_PrevResetState_fl', int8_T),
    ('Integrator_PrevResetState_b', int8_T),
    ('Integrator_PrevResetState_o', int8_T),
    ('Integrator_PrevResetState_m', int8_T),
    ('Integrator_PrevResetState_ez', int8_T),
    ('Integrator_PrevResetState_g', int8_T),
    ('icLoad', boolean_T),
    ('icLoad_i', boolean_T),
    ('icLoad_e', boolean_T),
    ('icLoad_iz', boolean_T),
    ('icLoad_m', boolean_T),
    ('SetMode_MODE', boolean_T),
    ('CalibrationAverage_MODE', boolean_T),
    ('CalibrationAverage_MODE_c', boolean_T),
    ('VoltageInjection_MODE', boolean_T),
    ('slew_rate_MODE', boolean_T),
    ('PI_Te_MODE', boolean_T),
    ('PI_spd_PI_Te_Fric_Comp_MODE', boolean_T),
    ('P_pos_PI_spd_PI_Te_Fric_Comp_MO', boolean_T),
    ('Openloop_MODE', boolean_T),
    ('Impedance_Controller_2_Fric_Com', boolean_T),
    ('slew_rate_ok', DW_slew_rate_DT_T),
    ('DOB_e', DW_DOB_DT_T),
    ('slew_rate_o', DW_slew_rate_DT_T),
    ('slew_rate_g', DW_slew_rate_DT_T),
    ('DOB_b', DW_DOB_DT_T),
    ('slew_rate', DW_slew_rate_DT_T),
    ('DOB', DW_DOB_DT_T),
]

DW_DT_T = struct_anon_18# DT.h: 156

# DT.h: 161
class struct_anon_19(Structure):
    pass

struct_anon_19.__slots__ = [
    'Resetoffsets_i',
    'Resetoffsets',
]
struct_anon_19._fields_ = [
    ('Resetoffsets_i', ZCE_Resetoffsets_DT_T),
    ('Resetoffsets', ZCE_Resetoffsets_DT_T),
]

PrevZCX_DT_T = struct_anon_19# DT.h: 161

# DT.h: 218
class struct_anon_20(Structure):
    pass

struct_anon_20.__slots__ = [
    'TmpBufferAtTmpGroundAtDataI',
    'TmpBufferAtTmpGroundAtDat_p',
    'TmpBufferAtTmpGroundAtDat_e',
    'TmpBufferAtTmpGroundAtDat_k',
    'TmpBufferAtTmpGroundAtDat_m',
    'TmpBufferAtTmpGroundAtDat_g',
    'TmpBufferAtTmpGroundAtDat_j',
    'TmpBufferAtTmpGroundAtDa_jf',
    'Product',
    'Product_h',
    'TmpBufferAtConstantOutport1',
    'TmpBufferAtTmpGroundAtDat_f',
    'TmpBufferAtTmpGroundAtDat_o',
    'TmpBufferAtTmpGroundAtDat_b',
    'TmpBufferAtTmpGroundAtDat_h',
    'TmpBufferAtid_refOutport1',
    'TmpBufferAtTmpGroundAtDa_k4',
    'TmpBufferAtTmpGroundForTmpG',
    'TmpBufferAtid_refOutport1_d',
    'TmpBufferAtTmpGroundAtDa_pu',
    'TmpBufferAtid_refOutport1_p',
    'TmpBufferAtTmpGroundAtDat_i',
    'TmpBufferAtTmpGroundAtDa_ha',
    'TmpBufferAtTmpGroundAtDa_e0',
    'TmpBufferAtVd_OpenLoopOutpo',
    'TmpBufferAtid_refOutport_pk',
    'TmpBufferAtGround1Outport1',
    'TmpBufferAtTmpGroundAtDat_l',
    'TmpBufferAtTmpGroundAtDa_hp',
    'TmpBufferAtTmpGroundAtDa_i0',
    'TmpBufferAtTmpGroundAtDa_lg',
    'TmpBufferAtTmpGroundAtDa_fg',
    'TmpBufferAtTmpGroundAtDat_c',
    'TmpBufferAtTmpGroundAtDa_pg',
    'Cast',
    'Gain1',
    'Bias',
    'Cast_p',
    'Gain1_f',
    'Bias_d',
    'Cast_g',
    'Gain1_f3',
    'Bias_i',
    'Cast_m',
    'Gain1_n',
    'Bias_a',
    'Switch',
    'Switch_c',
    'XOR',
    'XOR_d',
    'XOR_n',
    'XOR_a',
    'XOR_c',
    'XOR_nc',
]
struct_anon_20._fields_ = [
    ('TmpBufferAtTmpGroundAtDataI', real_T),
    ('TmpBufferAtTmpGroundAtDat_p', real_T),
    ('TmpBufferAtTmpGroundAtDat_e', real_T),
    ('TmpBufferAtTmpGroundAtDat_k', real_T),
    ('TmpBufferAtTmpGroundAtDat_m', real_T),
    ('TmpBufferAtTmpGroundAtDat_g', real_T),
    ('TmpBufferAtTmpGroundAtDat_j', real_T),
    ('TmpBufferAtTmpGroundAtDa_jf', real_T),
    ('Product', real32_T),
    ('Product_h', real32_T),
    ('TmpBufferAtConstantOutport1', real32_T),
    ('TmpBufferAtTmpGroundAtDat_f', real32_T),
    ('TmpBufferAtTmpGroundAtDat_o', real32_T),
    ('TmpBufferAtTmpGroundAtDat_b', real32_T),
    ('TmpBufferAtTmpGroundAtDat_h', real32_T * int(2)),
    ('TmpBufferAtid_refOutport1', real32_T),
    ('TmpBufferAtTmpGroundAtDa_k4', real32_T),
    ('TmpBufferAtTmpGroundForTmpG', real32_T),
    ('TmpBufferAtid_refOutport1_d', real32_T),
    ('TmpBufferAtTmpGroundAtDa_pu', real32_T),
    ('TmpBufferAtid_refOutport1_p', real32_T),
    ('TmpBufferAtTmpGroundAtDat_i', real32_T),
    ('TmpBufferAtTmpGroundAtDa_ha', real32_T),
    ('TmpBufferAtTmpGroundAtDa_e0', real32_T * int(2)),
    ('TmpBufferAtVd_OpenLoopOutpo', real32_T),
    ('TmpBufferAtid_refOutport_pk', real32_T),
    ('TmpBufferAtGround1Outport1', real32_T),
    ('TmpBufferAtTmpGroundAtDat_l', real32_T),
    ('TmpBufferAtTmpGroundAtDa_hp', real32_T),
    ('TmpBufferAtTmpGroundAtDa_i0', real32_T),
    ('TmpBufferAtTmpGroundAtDa_lg', real32_T),
    ('TmpBufferAtTmpGroundAtDa_fg', real32_T),
    ('TmpBufferAtTmpGroundAtDat_c', real32_T),
    ('TmpBufferAtTmpGroundAtDa_pg', real32_T * int(2)),
    ('Cast', int32_T),
    ('Gain1', int32_T),
    ('Bias', int32_T),
    ('Cast_p', int32_T),
    ('Gain1_f', int32_T),
    ('Bias_d', int32_T),
    ('Cast_g', int32_T),
    ('Gain1_f3', int32_T),
    ('Bias_i', int32_T),
    ('Cast_m', int32_T),
    ('Gain1_n', int32_T),
    ('Bias_a', int32_T),
    ('Switch', uint8_T * int(3)),
    ('Switch_c', uint8_T * int(3)),
    ('XOR', boolean_T),
    ('XOR_d', boolean_T),
    ('XOR_n', boolean_T),
    ('XOR_a', boolean_T),
    ('XOR_c', boolean_T),
    ('XOR_nc', boolean_T),
]

ConstB_DT_T = struct_anon_20# DT.h: 218

# DT.h: 223
class struct_anon_21(Structure):
    pass

struct_anon_21.__slots__ = [
    'Current_Value',
    'Scaling_Gain',
]
struct_anon_21._fields_ = [
    ('Current_Value', real32_T * int(6)),
    ('Scaling_Gain', real32_T * int(3)),
]

ConstP_DT_T = struct_anon_21# DT.h: 223

# DT.h: 228
class struct_Filter_tag(Structure):
    pass

struct_Filter_tag.__slots__ = [
    'current_cutoff',
    'spd_cutoff',
]
struct_Filter_tag._fields_ = [
    ('current_cutoff', real_T),
    ('spd_cutoff', real_T),
]

Filter_type = struct_Filter_tag# DT.h: 228

# DT.h: 235
class struct_Impedance_tag(Structure):
    pass

struct_Impedance_tag.__slots__ = [
    'J_imp',
    'K_damp',
    'K_stiff',
    'T_FF',
]
struct_Impedance_tag._fields_ = [
    ('J_imp', real32_T),
    ('K_damp', real32_T),
    ('K_stiff', real32_T),
    ('T_FF', real32_T),
]

Impedance_type = struct_Impedance_tag# DT.h: 235

# DT.h: 244
class struct_PID_tag(Structure):
    pass

struct_PID_tag.__slots__ = [
    'FF_gain',
    'id_Ki',
    'id_Kp',
    'pos_Kp',
    'spd_Ki',
    'spd_Kp',
]
struct_PID_tag._fields_ = [
    ('FF_gain', real32_T),
    ('id_Ki', real32_T),
    ('id_Kp', real32_T),
    ('pos_Kp', real32_T),
    ('spd_Ki', real32_T),
    ('spd_Kp', real32_T),
]

PID_type = struct_PID_tag# DT.h: 244

# DT.h: 257
class struct_debug_tag(Structure):
    pass

struct_debug_tag.__slots__ = [
    'T_fb_max',
    'T_ref_max',
    'i_max',
    'pos_fb_max',
    'pos_fb_min',
    'pos_ref_max',
    'pos_ref_min',
    'spd_fb_max',
    'spd_ref_max',
    'spd_ref_min',
]
struct_debug_tag._fields_ = [
    ('T_fb_max', boolean_T),
    ('T_ref_max', boolean_T),
    ('i_max', boolean_T),
    ('pos_fb_max', boolean_T),
    ('pos_fb_min', boolean_T),
    ('pos_ref_max', boolean_T),
    ('pos_ref_min', boolean_T),
    ('spd_fb_max', boolean_T),
    ('spd_ref_max', boolean_T),
    ('spd_ref_min', boolean_T),
]

debug_type = struct_debug_tag# DT.h: 257

# DT.h: 274
class struct_info_tag(Structure):
    pass

struct_info_tag.__slots__ = [
    'enable',
    'temp_winding',
    'T_fb',
    'T_ref',
    'id_fb',
    'id_ref',
    'iq_fb',
    'iq_ref',
    'pos_fb',
    'pos_ref',
    'spd_fb',
    'spd_ref',
    'vd_ref',
    'vq_ref',
]
struct_info_tag._fields_ = [
    ('enable', real_T),
    ('temp_winding', real_T),
    ('T_fb', real32_T),
    ('T_ref', real32_T),
    ('id_fb', real32_T),
    ('id_ref', real32_T),
    ('iq_fb', real32_T),
    ('iq_ref', real32_T),
    ('pos_fb', real32_T),
    ('pos_ref', real32_T),
    ('spd_fb', real32_T),
    ('spd_ref', real32_T),
    ('vd_ref', real32_T),
    ('vq_ref', real32_T),
]

info_type = struct_info_tag# DT.h: 274

# DT.h: 286
class struct_inports_tag(Structure):
    pass

struct_inports_tag.__slots__ = [
    'Load',
    'Reference',
    'T_ADC',
    'ref_ff_torque',
    'ref_impedance_acel',
    'ref_impedance_spd',
    'ControlType',
    'Enable',
    'ResetPos',
]
struct_inports_tag._fields_ = [
    ('Load', real32_T),
    ('Reference', real32_T),
    ('T_ADC', real32_T),
    ('ref_ff_torque', real32_T),
    ('ref_impedance_acel', real32_T),
    ('ref_impedance_spd', real32_T),
    ('ControlType', uint8_T),
    ('Enable', boolean_T),
    ('ResetPos', boolean_T),
]

inports_type = struct_inports_tag# DT.h: 286

# DT.h: 298
class struct_lim_tag(Structure):
    pass

struct_lim_tag.__slots__ = [
    'lim_T',
    'lim_pos_max',
    'lim_pos_min',
    'lim_spd_max',
    'lim_spd_min',
    'prof_pos_max',
    'prof_pos_min',
    'prof_spd_max',
    'prof_spd_min',
]
struct_lim_tag._fields_ = [
    ('lim_T', real32_T),
    ('lim_pos_max', real32_T),
    ('lim_pos_min', real32_T),
    ('lim_spd_max', real32_T),
    ('lim_spd_min', real32_T),
    ('prof_pos_max', real32_T),
    ('prof_pos_min', real32_T),
    ('prof_spd_max', real32_T),
    ('prof_spd_min', real32_T),
]

lim_type = struct_lim_tag# DT.h: 298

# DT.h: 318
class struct_meas_tag(Structure):
    pass

struct_meas_tag.__slots__ = [
    'turn',
    'turn1_offset',
    'turn2',
    'turn2_offset',
    'T',
    'T_offset',
    'e_pos',
    'iabc',
    'iabc_offset',
    'idq',
    'pos',
    'pos1_offset',
    'pos2',
    'pos2_offset',
    'pos_offset',
    'spd',
    'spd2',
]
struct_meas_tag._fields_ = [
    ('turn', int32_T),
    ('turn1_offset', int32_T),
    ('turn2', int32_T),
    ('turn2_offset', int32_T),
    ('T', real32_T),
    ('T_offset', real32_T),
    ('e_pos', real32_T),
    ('iabc', real32_T * int(3)),
    ('iabc_offset', real32_T * int(3)),
    ('idq', real32_T * int(2)),
    ('pos', real32_T),
    ('pos1_offset', real32_T),
    ('pos2', real32_T),
    ('pos2_offset', real32_T),
    ('pos_offset', real32_T),
    ('spd', real32_T),
    ('spd2', real32_T),
]

meas_type = struct_meas_tag# DT.h: 318

# DT.h: 344
class struct_motor_tag(Structure):
    pass

struct_motor_tag.__slots__ = [
    'm_Te',
    'm_Tl',
    'm_acc',
    'm_eff_elec',
    'm_eff_mec',
    'm_i_dc',
    'm_ia',
    'm_ib',
    'm_ic',
    'm_id',
    'm_iq',
    'm_pos1',
    'm_pos2',
    'm_pwr_dc',
    'm_pwr_elec',
    'm_pwr_mec',
    'm_spd1',
    'm_spd2',
    'm_va',
    'm_vb',
    'm_vc',
    'm_vd',
    'm_vq',
]
struct_motor_tag._fields_ = [
    ('m_Te', real_T),
    ('m_Tl', real_T),
    ('m_acc', real_T),
    ('m_eff_elec', real_T),
    ('m_eff_mec', real_T),
    ('m_i_dc', real_T),
    ('m_ia', real_T),
    ('m_ib', real_T),
    ('m_ic', real_T),
    ('m_id', real_T),
    ('m_iq', real_T),
    ('m_pos1', real_T),
    ('m_pos2', real_T),
    ('m_pwr_dc', real_T),
    ('m_pwr_elec', real_T),
    ('m_pwr_mec', real_T),
    ('m_spd1', real_T),
    ('m_spd2', real_T),
    ('m_va', real_T),
    ('m_vb', real_T),
    ('m_vc', real_T),
    ('m_vd', real_T),
    ('m_vq', real_T),
]

motor_type = struct_motor_tag# DT.h: 344

struct_tag_RTM_DT_T.__slots__ = [
    'errorStatus',
]
struct_tag_RTM_DT_T._fields_ = [
    ('errorStatus', POINTER(char_T)),
]

# DT.h: 350
for _lib in _libs.values():
    try:
        DT_B = (B_DT_T).in_dll(_lib, "DT_B")
        break
    except:
        pass

# DT.h: 351
for _lib in _libs.values():
    try:
        DT_DW = (DW_DT_T).in_dll(_lib, "DT_DW")
        break
    except:
        pass

# DT.h: 352
for _lib in _libs.values():
    try:
        DT_PrevZCX = (PrevZCX_DT_T).in_dll(_lib, "DT_PrevZCX")
        break
    except:
        pass

# DT.h: 353
for _lib in _libs.values():
    try:
        DT_ConstB = (ConstB_DT_T).in_dll(_lib, "DT_ConstB")
        break
    except:
        pass

# DT.h: 354
for _lib in _libs.values():
    try:
        DT_ConstP = (ConstP_DT_T).in_dll(_lib, "DT_ConstP")
        break
    except:
        pass

# DT.h: 355
for _lib in _libs.values():
    if not _lib.has("DT_initialize", "cdecl"):
        continue
    DT_initialize = _lib.get("DT_initialize", "cdecl")
    DT_initialize.argtypes = []
    DT_initialize.restype = None
    break

# DT.h: 356
for _lib in _libs.values():
    if not _lib.has("DT_step", "cdecl"):
        continue
    DT_step = _lib.get("DT_step", "cdecl")
    DT_step.argtypes = []
    DT_step.restype = None
    break

# DT.h: 357
for _lib in _libs.values():
    if not _lib.has("DT_terminate", "cdecl"):
        continue
    DT_terminate = _lib.get("DT_terminate", "cdecl")
    DT_terminate.argtypes = []
    DT_terminate.restype = None
    break

# DT.h: 358
for _lib in _libs.values():
    try:
        Filter = (Filter_type).in_dll(_lib, "Filter")
        break
    except:
        pass

# DT.h: 359
for _lib in _libs.values():
    try:
        Impedance = (Impedance_type).in_dll(_lib, "Impedance")
        break
    except:
        pass

# DT.h: 360
for _lib in _libs.values():
    try:
        PID = (PID_type).in_dll(_lib, "PID")
        break
    except:
        pass

# DT.h: 361
for _lib in _libs.values():
    try:
        debug = (debug_type).in_dll(_lib, "debug")
        break
    except:
        pass

# DT.h: 362
for _lib in _libs.values():
    try:
        info = (info_type).in_dll(_lib, "info")
        break
    except:
        pass

# DT.h: 363
for _lib in _libs.values():
    try:
        inports = (inports_type).in_dll(_lib, "inports")
        break
    except:
        pass

# DT.h: 364
for _lib in _libs.values():
    try:
        lim = (lim_type).in_dll(_lib, "lim")
        break
    except:
        pass

# DT.h: 365
for _lib in _libs.values():
    try:
        meas = (meas_type).in_dll(_lib, "meas")
        break
    except:
        pass

# DT.h: 366
for _lib in _libs.values():
    try:
        motor = (motor_type).in_dll(_lib, "motor")
        break
    except:
        pass

# DT.h: 367
for _lib in _libs.values():
    try:
        DT_M = (POINTER(RT_MODEL_DT_T)).in_dll(_lib, "DT_M")
        break
    except:
        pass

# interface.h: 9
for _lib in _libs.values():
    if not _lib.has("get_impedance_ptr", "cdecl"):
        continue
    get_impedance_ptr = _lib.get("get_impedance_ptr", "cdecl")
    get_impedance_ptr.argtypes = []
    get_impedance_ptr.restype = POINTER(Impedance_type)
    break

# interface.h: 10
for _lib in _libs.values():
    if not _lib.has("get_pid_ptr", "cdecl"):
        continue
    get_pid_ptr = _lib.get("get_pid_ptr", "cdecl")
    get_pid_ptr.argtypes = []
    get_pid_ptr.restype = POINTER(PID_type)
    break

# interface.h: 11
for _lib in _libs.values():
    if not _lib.has("get_debug_ptr", "cdecl"):
        continue
    get_debug_ptr = _lib.get("get_debug_ptr", "cdecl")
    get_debug_ptr.argtypes = []
    get_debug_ptr.restype = POINTER(debug_type)
    break

# interface.h: 12
for _lib in _libs.values():
    if not _lib.has("get_info_ptr", "cdecl"):
        continue
    get_info_ptr = _lib.get("get_info_ptr", "cdecl")
    get_info_ptr.argtypes = []
    get_info_ptr.restype = POINTER(info_type)
    break

# interface.h: 13
for _lib in _libs.values():
    if not _lib.has("get_inports_ptr", "cdecl"):
        continue
    get_inports_ptr = _lib.get("get_inports_ptr", "cdecl")
    get_inports_ptr.argtypes = []
    get_inports_ptr.restype = POINTER(inports_type)
    break

# interface.h: 14
for _lib in _libs.values():
    if not _lib.has("get_lim_ptr", "cdecl"):
        continue
    get_lim_ptr = _lib.get("get_lim_ptr", "cdecl")
    get_lim_ptr.argtypes = []
    get_lim_ptr.restype = POINTER(lim_type)
    break

# interface.h: 15
for _lib in _libs.values():
    if not _lib.has("get_meas_ptr", "cdecl"):
        continue
    get_meas_ptr = _lib.get("get_meas_ptr", "cdecl")
    get_meas_ptr.argtypes = []
    get_meas_ptr.restype = POINTER(meas_type)
    break

# interface.h: 16
for _lib in _libs.values():
    if not _lib.has("get_motor_ptr", "cdecl"):
        continue
    get_motor_ptr = _lib.get("get_motor_ptr", "cdecl")
    get_motor_ptr.argtypes = []
    get_motor_ptr.restype = POINTER(motor_type)
    break

tag_RTM_DT_T = struct_tag_RTM_DT_T# DT.h: 346

Filter_tag = struct_Filter_tag# DT.h: 228

Impedance_tag = struct_Impedance_tag# DT.h: 235

PID_tag = struct_PID_tag# DT.h: 244

debug_tag = struct_debug_tag# DT.h: 257

info_tag = struct_info_tag# DT.h: 274

inports_tag = struct_inports_tag# DT.h: 286

lim_tag = struct_lim_tag# DT.h: 298

meas_tag = struct_meas_tag# DT.h: 318

motor_tag = struct_motor_tag# DT.h: 344

# No inserted files

# No prefix-stripping

