# Dummy binding placeholder for installer tests.
MODEL_NAME = "DUMMY"
PLATFORM_KEY = "ARMCompatible_ARM64bitLP64"
