# Dummy binding placeholder for installer tests.
MODEL_NAME = "DUMMY"
PLATFORM_KEY = "Apple_ARM64"
