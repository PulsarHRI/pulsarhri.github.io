# Dummy binding placeholder for installer tests.
MODEL_NAME = "DUMMY"
PLATFORM_KEY = "AMD_x8664Linux64"
