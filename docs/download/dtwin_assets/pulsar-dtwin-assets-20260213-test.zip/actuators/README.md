Dummy DTwin assets for installer and documentation workflow tests.
These files do not contain a real generated digital twin model.
