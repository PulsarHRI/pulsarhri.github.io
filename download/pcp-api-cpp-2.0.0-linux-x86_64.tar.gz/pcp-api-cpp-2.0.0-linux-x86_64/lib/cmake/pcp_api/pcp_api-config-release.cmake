#----------------------------------------------------------------
# Generated CMake target import file for configuration "Release".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "pcp_api::pcp_api" for configuration "Release"
set_property(TARGET pcp_api::pcp_api APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(pcp_api::pcp_api PROPERTIES
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/libpcp_api.so.2.0.0"
  IMPORTED_SONAME_RELEASE "libpcp_api.so.0"
  )

list(APPEND _cmake_import_check_targets pcp_api::pcp_api )
list(APPEND _cmake_import_check_files_for_pcp_api::pcp_api "${_IMPORT_PREFIX}/lib/libpcp_api.so.2.0.0" )

# Import target "pcp_api::pcp_api_static" for configuration "Release"
set_property(TARGET pcp_api::pcp_api_static APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(pcp_api::pcp_api_static PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_RELEASE "CXX"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/libpcp_api_static.a"
  )

list(APPEND _cmake_import_check_targets pcp_api::pcp_api_static )
list(APPEND _cmake_import_check_files_for_pcp_api::pcp_api_static "${_IMPORT_PREFIX}/lib/libpcp_api_static.a" )

# Import target "pcp_api::pulsar-cli" for configuration "Release"
set_property(TARGET pcp_api::pulsar-cli APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(pcp_api::pulsar-cli PROPERTIES
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/bin/pulsar-cli"
  )

list(APPEND _cmake_import_check_targets pcp_api::pulsar-cli )
list(APPEND _cmake_import_check_files_for_pcp_api::pulsar-cli "${_IMPORT_PREFIX}/bin/pulsar-cli" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
