#pragma once

#include <cstdint>
#include <functional>
#include <mutex>
#include <string>
#include <unordered_map>
#include <vector>

namespace pcp_api {

/// Callback type for PCP message reception.
/// Parameters: address, payload data, priority bit
using PcpCallback = std::function<void(int, std::vector<uint8_t>, int)>;

/// Base class for PCP (Pulsar Communication Protocol) adapters.
/// Subclasses must implement connect(), disconnect(), is_connected(), and send_PCP().
class PCP {
public:
    static constexpr uint8_t MSG_START_BYTE = 0xFE;
    static constexpr int MSG_HEADER_LENGTH = 4;
    static constexpr int MAX_PAYLOAD_SIZE = 59;
    static constexpr uint8_t CRC_MAGIC_NUMBER = 0xFD;

    PCP();
    virtual ~PCP();

    /// Register a callback for messages from a specific address
    void setCallback(int address, PcpCallback callback);

    /// Remove the callback for a specific address
    void removeCallback(int address);

    /// Alias for disconnect()
    void close();

    /// Check if a PCP ID is in valid range (0x0000 to 0x3FFE)
    static bool check_pcp_id_range(int can_id);

    /// Check if payload size is within valid bounds
    static bool check_pcp_payload_size(const std::vector<uint8_t>& payload);

    /// Connect to the device (implemented by subclass)
    virtual bool connect(const std::string& port = "") = 0;

    /// Disconnect from the device (implemented by subclass)
    virtual void disconnect() = 0;

    /// Check connection status (implemented by subclass)
    virtual bool is_connected() const = 0;

    /// Send a PCP message (implemented by subclass)
    virtual bool send_PCP(int address, const std::vector<uint8_t>& data) = 0;

protected:
    /// Build a PCP identifier from source and destination addresses
    static int build_CPC_identifier(int source, int destination);

    std::unordered_map<int, PcpCallback> callbacks_;
    std::mutex lock_;
    int adapter_address_ = 0x01;
};

} // namespace pcp_api
