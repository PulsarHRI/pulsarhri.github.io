#pragma once

#include "pcp.hpp"
#include <atomic>
#include <memory>
#include <string>
#include <thread>
#include <vector>

namespace pcp_api {

// Forward declaration — implementation detail
class SerialPort;

/// PCP adapter for USB serial connections.
/// Provides USB serial communication for the PCP protocol, with
/// a background thread for asynchronous message reception.
class PCP_over_USB : public PCP {
public:
    /// Initialize PCP over USB adapter.
    /// @param port Serial port (e.g., "/dev/ttyACM0", "COM3"). Empty for auto-discovery.
    /// @param connect_on_init Whether to connect during initialization.
    explicit PCP_over_USB(const std::string& port = "", bool connect_on_init = true);
    ~PCP_over_USB() override;

    // Non-copyable (owns a thread)
    PCP_over_USB(const PCP_over_USB&) = delete;
    PCP_over_USB& operator=(const PCP_over_USB&) = delete;

    /// Connect to the USB serial device.
    bool connect(const std::string& port = "") override;

    /// Disconnect and stop the background polling thread.
    void disconnect() override;

    /// Check if the USB connection is active.
    bool is_connected() const override;

    /// Send a PCP message to the specified address.
    bool send_PCP(int address, const std::vector<uint8_t>& data) override;

    /// Put the CAN adapter into bootloader mode.
    void enter_bootloader();

    /// Get list of available Pulsar HRI USB serial ports (filtered by VID/PID).
    static std::vector<std::string> get_ports();

    /// Auto-discover a single Pulsar HRI serial port.
    static std::string get_port();

private:
    void polling_thread_worker();
    void process_pkt(int address, const std::vector<uint8_t>& pkt, int priority_bit);

    std::string port_;
    std::unique_ptr<SerialPort> ser_;
    std::atomic<bool> polling_event_{false};
    std::thread polling_thread_;
};

} // namespace pcp_api
