#pragma once
#include <cstdint>
#include <cstring>
#include <vector>

namespace pcp_api {

// ---------------------------------------------------------------------
// Little-endian pack/unpack helpers (matching STM32 byte order)
// These replace Python's struct.pack('<f', ...) / struct.unpack('<H', ...)
// ---------------------------------------------------------------------

inline std::vector<uint8_t> pack_float(float val) {
    std::vector<uint8_t> buf(sizeof(float));
    std::memcpy(buf.data(), &val, sizeof(float));
    return buf;
}

inline std::vector<uint8_t> pack_uint16(uint16_t val) {
    std::vector<uint8_t> buf(sizeof(uint16_t));
    std::memcpy(buf.data(), &val, sizeof(uint16_t));
    return buf;
}

inline std::vector<uint8_t> pack_uint32(uint32_t val) {
    std::vector<uint8_t> buf(sizeof(uint32_t));
    std::memcpy(buf.data(), &val, sizeof(uint32_t));
    return buf;
}

inline float unpack_float(const uint8_t* data) {
    float val;
    std::memcpy(&val, data, sizeof(float));
    return val;
}

inline uint16_t unpack_uint16(const uint8_t* data) {
    uint16_t val;
    std::memcpy(&val, data, sizeof(uint16_t));
    return val;
}

inline uint32_t unpack_uint32(const uint8_t* data) {
    uint32_t val;
    std::memcpy(&val, data, sizeof(uint32_t));
    return val;
}

inline int32_t unpack_int32(const uint8_t* data) {
    int32_t val;
    std::memcpy(&val, data, sizeof(int32_t));
    return val;
}

// Append packed bytes to a message buffer
inline void append_float(std::vector<uint8_t>& msg, float val) {
    auto bytes = pack_float(val);
    msg.insert(msg.end(), bytes.begin(), bytes.end());
}

inline void append_uint16(std::vector<uint8_t>& msg, uint16_t val) {
    auto bytes = pack_uint16(val);
    msg.insert(msg.end(), bytes.begin(), bytes.end());
}

inline void append_uint32(std::vector<uint8_t>& msg, uint32_t val) {
    auto bytes = pack_uint32(val);
    msg.insert(msg.end(), bytes.begin(), bytes.end());
}

} // namespace pcp_api
