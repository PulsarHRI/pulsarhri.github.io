#pragma once

#include "pcp.hpp"
#include "utils.hpp"

#include <atomic>
#include <chrono>
#include <cmath>
#include <cstdint>
#include <functional>
#include <iostream>
#include <string>
#include <thread>
#include <unordered_map>
#include <vector>

namespace pcp_api {

/// Main class for controlling Pulsar actuators via PCP (Pulsar Control Protocol).
class PulsarActuator {
public:
    static inline const std::vector<std::string> MODELS_NAMES = {
        "",
        "PULSE98",
        "PULSE115",
        "P90",
        "P100",
        "CAN_ADAPTER",
        "P43",
        "P60",
        "P28",
        "PULSE35",
        "PULSE80",
    };

    enum class Mode : uint8_t {
        FVI = 2,
        OPEN_LOOP = 3,
        DVI = 4,
        TORQUE = 5,
        SPEED = 6,
        POSITION = 7,
        IMPEDANCE = 8,
    };

    enum class Rates : uint16_t {
        DISABLED = 0,
        RATE_2KHZ = 5,
        RATE_1KHZ = 10,
        RATE_500HZ = 0x14,
        RATE_200HZ = 0x32,
        RATE_100HZ = 0x64,
        RATE_50HZ = 0xC8,
        RATE_20HZ = 0x1F4,
        RATE_10HZ = 0x3E8,
        RATE_5HZ = 0x7D0,
        RATE_2HZ = 0x1388,
        RATE_1HZ = 0x2710,
    };

    enum class TorquePerformance : uint8_t {
        AGGRESSIVE = 1,
        BALANCED = 2,
        SOFT = 3,
    };

    enum class SpeedPerformance : uint8_t {
        AGGRESSIVE = 1,
        BALANCED = 2,
        SOFT = 3,
        CUSTOM = 4,
    };

    enum class _PCP_Actions : uint8_t {
        START = 1,
        STOP = 2,
        CHANGE_MODE = 3,
        CHANGE_SETPOINT = 4,
        CHANGE_SETPOINT_FF = 0x10,
        CHANGE_SETPOINT_TORQUE = 0x11,
        CHANGE_SETPOINT_SPEED = 0x12,
        CHANGE_SETPOINT_POSITION = 0x13,
        CHANGE_SETPOINT_IMPEDANCE = 0x14,
        CHANGE_SETPOINT_SPEED_INTERNAL = 0x15,
        CHANGE_SETPOINT_POSITION_INTERNAL = 0x16,
        SET_FEEDBACK_HIGH_RATE = 6,
        SET_FEEDBACK_HIGH_ITEMS = 7,
        RESET_ENCODER_POSITION = 10,
        SET_PARAMETERS = 11,
        GET_PARAMETERS = 12,
        SET_TORQUE_PERFORMANCE = 13,
        SET_SPEED_PERFORMANCE = 14,
        GET_ITEMS = 15,
        START_SINE_REF = 0x38,
        SAVE = 0x39,
        PING = 0x40,
        BLINK = 0x41,
        ENTER_BOOTLOADER = 0xC1,
        DEBUG_CLEAR_CONFIG = 0xC2,
        DEBUG_RESET_INT_ENC = 0xC3,
        DEBUG_RESET_EXT_ENC = 0xC4,
    };

    enum class PCP_Parameters : uint8_t {
        K_DAMPING = 1,
        K_STIFFNESS = 2,
        TORQUE_FF = 3,
        LIM_TORQUE = 4,
        LIM_POSITION_MAX = 5,
        LIM_POSITION_MIN = 6,
        LIM_SPEED_MAX = 7,
        LIM_SPEED_MIN = 8,
        PROFILE_POSITION_MAX = 9,
        PROFILE_POSITION_MIN = 10,
        PROFILE_SPEED_MAX = 11,
        PROFILE_SPEED_MIN = 12,
        KP_SPEED = 13,
        KI_SPEED = 14,
        KP_POSITION = 15,
        MODE = 0x30,
        SETPOINT = 0x31,
        TORQUE_PERFORMANCE = 0x40,
        SPEED_PERFORMANCE = 0x41,
        PROFILE_SPEED_MAX_RAD_S = 0x42,
        PROFILE_TORQUE_MAX_NM = 0x43,
        FF_GAIN = 0x45,
        PCP_PARAM_SPEED_CUTOFF = 0x46,
        PCP_PARAM_CURRENT_CUTOFF = 0x47,
        INVERT_FLAG = 0x44,
        FIRMWARE_VERSION = 0x80,
        PCP_ADDRESS = 0x81,
        SERIAL_NUMBER = 0x82,
        DEVICE_MODEL = 0x83,
        CONTROL_VERSION = 0x84,
        CAN_HIGH_SPEED = 0x85,
    };

    enum class PCP_Items : uint8_t {
        ENCODER_INT = 0x41,
        ENCODER_INT_RAW = 0x42,
        ENCODER_EXT = 0x43,
        ENCODER_EXT_RAW = 0x44,
        SPEED_FB = 0x45,
        IA = 0x46,
        IB = 0x47,
        IC = 0x48,
        TORQUE_SENS = 0x49,
        TORQUE_SENS_RAW = 0x4A,
        POSITION_REF = 0x4B,
        POSITION_FB = 0x4C,
        POSITION_FB_INTERNAL = 0x73,
        SPEED_REF = 0x4D,
        ID_REF = 0x4F,
        ID_FB = 0x50,
        IQ_REF = 0x51,
        IQ_FB = 0x52,
        VD_REF = 0x53,
        VQ_REF = 0x54,
        TORQUE_REF = 0x55,
        TORQUE_FB = 0x56,
        REFERENCE_A_VOLTAGE = 0x57,
        REFERENCE_B_VOLTAGE = 0x58,
        REFERENCE_C_VOLTAGE = 0x59,
        BUS_POWER = 0x5A,
        BUS_CURRENT = 0x5B,
        THREE_PHASE_POWER = 0x5C,
        MECHANICAL_POWER = 0x5D,
        INVERTER_EFFICIENCY = 0x5E,
        MOTOR_EFFICIENCY = 0x5F,
        ERRORS_ENCODER_INT = 0x60,
        ERRORS_ENCODER_EXT = 0x61,
        ERRORS_OVERRUN = 0x62,
        VBUS = 0x70,
        TEMP_PCB = 0x71,
        TEMP_MOTOR = 0x72,
        DEBUG_SIGNAL_BOOL = 0x90,
        DEBUG_SIGNAL01 = 0x91,
        DEBUG_SIGNAL02 = 0x92,
        DEBUG_SIGNAL03 = 0x93,
        DEBUG_SIGNAL04 = 0x94,
        DEBUG_SIGNAL05 = 0x95,
        DEBUG_SIGNAL06 = 0x96,
        DEBUG_SIGNAL07 = 0x97,
        DEBUG_SIGNAL08 = 0x98,
        DEBUG_SIGNAL09 = 0x99,
        DEBUG_SIGNAL10 = 0x9A,
    };

    enum class _PCP_Other : uint8_t {
        BEACON = 0x80,
        ERRORS = 0x82,
        PARAMETERS = 0x83,
    };

/// Initialize a PulsarActuator instance.
/// @param adapter Reference to a PCP adapter (e.g., PCP_over_USB)
/// @param address PCP network address of the actuator (0x0001-0x3FFE)
PulsarActuator(PCP& adapter, int address);
~PulsarActuator();

/// Establish connection (sends ping and waits for response).
bool connect(float timeout = 1.0f);

/// Disconnect from the actuator.
void disconnect();

/// Set callback for high-frequency feedback data.
void set_feedback_callback(std::function<void(int, std::unordered_map<PCP_Items, float>)> callback);

/// Set callback for error notifications.
void set_error_callback(std::function<void(int, std::unordered_map<int, std::string>)> callback);

/// Get the latest feedback data.
std::unordered_map<PCP_Items, float> get_feedback() const;

/// Send ping and wait for response.
bool send_ping(float timeout = 1.0f);

/// Change the PCP address of the actuator.
void changeAddress(int new_address);

/// Enable the actuator control system.
void start();

/// Disable the actuator control system.
void stop();

/// Change the actuator control mode.
void change_mode(Mode mode);

/// Set the control setpoint for the current mode.
void change_setpoint(float setpoint, float ref_ff_torque = 0.0f, float ref_impedance_spd = 0.0f);

/// Save current configuration to non-volatile memory.
void save_config();

/// Clear configuration, resetting all parameters to defaults.
void clear_config();

/// Blink the actuator's LED for identification.
void blink();

/// Configure which items to include in high-frequency feedback.
void setFeedbackItems(const std::vector<PCP_Items>& items);

/// Set the update rate for high-frequency feedback.
/// @param rate Either a Rates enum value or an integer Hz value.
void setFeedbackRate(int rate);

/// Set the update rate for high-frequency feedback (enum overload).
void setFeedbackRate(Rates rate);

/// Request specific feedback items and wait for response.
std::unordered_map<PCP_Items, float> getItemsBlocking(
    const std::vector<PCP_Items>& items, float timeout = 1.0f);

/// Set current position as home position (zero reference).
void set_home_position();

/// Enter bootloader mode.
void enter_bootloader();

/// Set multiple actuator parameters.
void set_parameters(const std::unordered_map<PCP_Parameters, float>& parameters);

/// Read multiple actuator parameters.
std::unordered_map<PCP_Parameters, float> get_parameters(
    const std::vector<PCP_Parameters>& parameters, float timeout = 1.0f);

/// Read all available actuator parameters.
std::unordered_map<PCP_Parameters, float> get_parameters_all();

/// Set torque control performance level.
void set_torque_performance(TorquePerformance performance);

/// Set speed control performance level.
void set_speed_performance(SpeedPerformance performance);

        // --- Auto-translated methods ---
    void change_torque_setpoint(float setpoint, float id_Kp = NAN, float id_Ki = NAN, float iq_Kp = NAN, float iq_Ki = NAN);
    void change_speed_setpoint(float setpoint, float FF_gain = NAN, float spd_Ki = NAN, float spd_Kp = NAN, float ref_ff_torque = NAN);
    void change_position_setpoint(float setpoint, float FF_gain = NAN, float spd_Ki = NAN, float spd_Kp = NAN, float pos_Kp = NAN, float ref_ff_torque = NAN);
    void change_impedance_setpoint(float setpoint, float FF_gain = NAN, float K_stiff = NAN, float K_damp = NAN, float J_imp = NAN, float ref_ff_torque = NAN, float ref_impedance_spd = NAN, float ref_impedance_acel = NAN);
    void internal_change_speed_setpoint(float setpoint, float spd_b0 = NAN, float spd_wc = NAN, float spd_wo = NAN);
    void internal_change_position_setpoint(float setpoint, float pos_Ki = NAN, float pos_Kd = NAN, float pos_b0 = NAN, float pos_wc = NAN, float pos_wo = NAN, float spd_b0 = NAN, float spd_wc = NAN, float spd_wo = NAN);

    // Accessors
    int address() const { return address_; }
    const std::string& model() const { return model_; }
    const std::string& firmware_version() const { return firmware_version_; }
    bool connected() const { return connected_; }

protected:
    bool send_pcp_common(const std::vector<uint8_t>& msg);
    void can_callback(int address, std::vector<uint8_t> data, int priority);
    void parse_parameters(const std::vector<uint8_t>& data, int offset);
    void parse_errors(uint32_t error_value);
    void default_error_callback(int address, const std::unordered_map<int, std::string>& errors);
    static std::string parse_firmware_version(uint16_t firmware_version_uint16);

    PCP& adapter_;
    int address_;
    std::string model_;
    std::string firmware_version_ = "x.x.x";
    bool connected_ = false;
    Mode current_mode_ = static_cast<Mode>(0);
    std::atomic<bool> got_pong_{false};
    std::atomic<bool> got_parameters_{false};
    std::unordered_map<PCP_Items, float> feedback_;
    std::unordered_map<PCP_Items, float> low_feedback_;
    std::unordered_map<PCP_Parameters, float> parameters_;
    std::function<void(int, std::unordered_map<PCP_Items, float>)> feedback_callback_;
    std::function<void(int, std::unordered_map<int, std::string>)> error_callback_;
    std::mutex feedback_mutex_;
};


/// Scanner for discovering Pulsar actuators on the PCP network.
class PulsarActuatorScanner : public PulsarActuator {
public:
    PulsarActuatorScanner(PCP& adapter);
    ~PulsarActuatorScanner() = default;

    /// Scan for actuators within the specified address range.
    std::vector<int> scan(int begin = 0x0010, int end = 0x3FFE);
};

} // namespace pcp_api
